package com.example.mylibrary;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.bumptech.glide.GlideContext;

import java.util.ArrayList;

public class bookActivity extends AppCompatActivity {
    private RecyclerView rec;
    private recAdap adap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book);

        rec = findViewById(R.id.rec);
        adap = new recAdap(this);

        rec.setAdapter(adap);
        rec.setLayoutManager(new LinearLayoutManager(this));

        adap.setBooks(Utils.getInstance().getAllBooks());

    }
}