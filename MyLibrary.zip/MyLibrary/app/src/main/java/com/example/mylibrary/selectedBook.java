package com.example.mylibrary;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class selectedBook extends AppCompatActivity {

    public static final String BOOK_ID_KEY = "bookId";

    private ImageView img;
    private Button btncurrentlyRdng, btnwantToRead, btnalreadyRead, btnfav;
    private TextView txt1, txt2, txt3, txt4, txt5, txt6, txt7, txt8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selected_book);

        img = findViewById(R.id.imageView2);
        btncurrentlyRdng = findViewById(R.id.button2);
        btnwantToRead = findViewById(R.id.button3);
        btnalreadyRead = findViewById(R.id.button4);
        btnfav = findViewById(R.id.button5);
        txt1 = findViewById(R.id.textView);
        txt2 = findViewById(R.id.textView2);
        txt3 = findViewById(R.id.textView3);
        txt4 = findViewById(R.id.textView4);
        txt5 = findViewById(R.id.textView5);
        txt6 = findViewById(R.id.textView6);
        txt7 = findViewById(R.id.textView7);
        txt8 = findViewById(R.id.textView8);

        Intent intent = getIntent();
        if (null != intent) {
            int bookId = intent.getIntExtra(BOOK_ID_KEY, -1);
            if (bookId != -1) {
                Book incomingBook = Utils.getInstance().getBookById(bookId);
                if (null != incomingBook) {
                    setData(incomingBook);

                    handleAlreadyRead(incomingBook);
                    handleWantToRead(incomingBook);
                    handleCurrentlyReading(incomingBook);
                    handleFavorite(incomingBook);
                }
            }
        }
    }

    private void setData(Book book) {
        txt5.setText(book.getName());
        txt6.setText(book.getAuthor());
        txt8.setText(String.valueOf(book.getPages()));
        txt4.setText(book.getShortdes());
        txt7.setText(book.getLongdes());
        Glide.with(this)
                .asBitmap().load(book.getImageURL())
                .into(img);
    }

    private void handleAlreadyRead(Book book) {
        ArrayList<Book> alreadyRead = Utils.getAlreadyReadBooks();

        boolean existInAlreadyRead = false;
        for (Book b : alreadyRead) {
            if (b.getId() == book.getId()) {
                existInAlreadyRead = true;
            }
        }
        if (existInAlreadyRead) {
            btnalreadyRead.setEnabled(false);   //disable the button
        } else {
            btnalreadyRead.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (Utils.getInstance().addToAlreadyRead(book)) {
                        Toast.makeText(selectedBook.this, "Book Added!", Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(selectedBook.this, AlreadyReadBookActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(selectedBook.this, "Something wrong!", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }

    private void handleWantToRead(Book book) {
        ArrayList<Book> wantToReadBooks = Utils.getWantToReadBooks();

        boolean existInWantToRead = false;
        for (Book b : wantToReadBooks) {
            if (b.getId() == book.getId()) {
                existInWantToRead = true;
            }
        }
        if (existInWantToRead) {
            btnwantToRead.setEnabled(false);   //disable the button
        } else {
            btnwantToRead.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (Utils.getInstance().addToWantToRead(book)) {
                        Toast.makeText(selectedBook.this, "Book Added!", Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(selectedBook.this, WantToReadActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(selectedBook.this, "Something wrong!", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }

    private void handleCurrentlyReading(Book book) {
        ArrayList<Book> currentlyReading = Utils.getCurrentlyReadingBooks();

        boolean existInCurrentlyRead = false;
        for (Book b : currentlyReading) {
            if (b.getId() == book.getId()) {
                existInCurrentlyRead = true;
            }
        }
        if (existInCurrentlyRead) {
            btncurrentlyRdng.setEnabled(false);   //disable the button
        } else {
            btncurrentlyRdng.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (Utils.getInstance().addToCurrentlyReading(book)) {
                        Toast.makeText(selectedBook.this, "Book Added!", Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(selectedBook.this, CurrentlyReadingActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(selectedBook.this, "Something wrong!", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }

    private void handleFavorite(Book book) {
        ArrayList<Book> fav = Utils.getFavoriteBooks();

        boolean existInFav = false;
        for (Book b : fav) {
            if (b.getId() == book.getId()) {
                existInFav = true;
            }
        }
        if (existInFav) {
            btnfav.setEnabled(false);   //disable the button
        } else {
            btnfav.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (Utils.getInstance().addToFav(book)) {
                        Toast.makeText(selectedBook.this, "Book Added!", Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(selectedBook.this, FavoriteActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(selectedBook.this, "Something wrong!", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }
}


