package com.example.mylibrary;

import static com.example.mylibrary.selectedBook.BOOK_ID_KEY;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class recAdap extends RecyclerView.Adapter<recAdap.ViewHolder> {
    private static final String TAG = "recAdap";  //const

    private ArrayList<Book> books = new ArrayList<>();
    private Context ncontext;

    public recAdap(Context ncontext) {
        this.ncontext = ncontext;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.booklist, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Log.d(TAG, "onBindViewHolder: called");
        holder.txt.setText(books.get(position).getName());
        Glide.with(ncontext).asBitmap().load(books.get(position).getImageURL()).into(holder.img);

        holder.parent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ncontext, selectedBook.class); //for load selectedBook activity
                intent.putExtra(BOOK_ID_KEY, books.get(holder.getAdapterPosition()).getId());//check if, keys are the same
                ncontext.startActivity(intent);
            }
        });


        holder.Auth.setText(books.get(position).getAuthor());
        holder.des.setText(books.get(position).getShortdes());
        if (books.get(position).isExpanded()) {
            holder.expdblRel.setVisibility(View.VISIBLE);
            holder.downArr.setVisibility(View.GONE);
        } else {
            holder.expdblRel.setVisibility(View.GONE);
            holder.downArr.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public int getItemCount() {
        return books.size();
    }

    public void setBooks(ArrayList<Book> books) {
        this.books = books;
        notifyDataSetChanged();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        private CardView parent;
        private ImageView img;
        private TextView txt;
        private ImageView downArr, upArr;
        private RelativeLayout colpsdRel, expdblRel;
        private TextView Auth, des;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            parent = itemView.findViewById(R.id.parent);
            img = itemView.findViewById(R.id.imgBook);
            txt = itemView.findViewById(R.id.bnametxt);
            downArr = itemView.findViewById(R.id.downArr);
            upArr = itemView.findViewById(R.id.upArr);
            colpsdRel = itemView.findViewById(R.id.clpsdRel);
            expdblRel = itemView.findViewById(R.id.expndblRel);
            Auth = itemView.findViewById(R.id.auth);
            des = itemView.findViewById(R.id.des);

            downArr.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Book book = books.get(getAdapterPosition());
                    book.setExpanded(!book.isExpanded());
                    notifyItemChanged(getAdapterPosition());
                }
            });
            upArr.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Book book = books.get(getAdapterPosition());
                    book.setExpanded(!book.isExpanded());
                    notifyItemChanged(getAdapterPosition());
                }
            });
        }
    }
}
