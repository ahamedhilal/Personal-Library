package com.example.mylibrary;

import java.util.ArrayList;

public class Utils {
    private static Utils instance;

    private static ArrayList<Book> allBooks;
    private static ArrayList<Book> alreadyReadBooks;
    private static ArrayList<Book> wantToReadBooks;
    private static ArrayList<Book> currentlyReadingBooks;
    private static ArrayList<Book> favoriteBooks;

    private Utils() {
        if (null == allBooks) {
            allBooks = new ArrayList<>();
            allBooks.add(new Book(1, "Harry Potter", "J. K. Rowling", 50, "https://www.libertybooks.com/image/cache/catalog/9781408855652-640x996.jpg?q6", "Philosopher's Stone (1997)", "Harry Potter and the Philosopher's Stone is an enthralling start to Harry's journey toward coming to terms with his past and facing his future. It was the first book written by Rowling, and she was praised for creating well-rounded characters and a fully realized wizard universe that coexisted with the present world."));
            allBooks.add(new Book(2, "Introduction to Basic Information and Communication Technology (ICT): Basic ICT ", "Emmanuel Kusi Achampong ", 720, "https://images-na.ssl-images-amazon.com/images/I/41RpQHmaMEL.jpg", "Intro to ICT", "Information and Communication Technology (ICT) is changing the lives of everyone. Through the teaching of ICT, people are equipped to participate in a rapidly changing world where learning, work and leisure activities are increasingly transformed by technology. This book is an introduction to the basics of ICT for students and everybody. It will help you learn basic topics like Information Processing, Parts of a Personal Computer, Health and Safety in Using ICT Tools, Introduction to the Desktop, Creating Word Processing Document, the Internet, Spreadsheet Application and other interesting topics."));
            allBooks.add(new Book(3, "C Programming Absolute Beginner's Guide", "Greg Perry ", 1830, "https://adnjxlogdq.cloudimg.io/v7/https://www.ishopping.pk/media/catalog/product/cache/1/image/1200x/9df78eab33525d08d6e5fb8d27136e95/c/_/c_programming_absolute_beginner_s_guide_book_3rd_edition.jpg", "Programming for begineers", " This is the best book for c programming. The book is a fast way to get into the comfort zone with C language, with step by step instructions. The book consists of 32 chapters, each discussing the core concepts of C programming along with clear and concise examples to help you understand better. Each chapter discusses a concept(s) in brief and then straightaway moves to code, following a practical over theory approach. The reader learns concepts such as organizing programs, storing and displaying data, variables, operators, I.O, functions, strings, and much more."));
            allBooks.add(new Book(4,"Android Studio Development Essentials","Neil Smyth",630,"https://images-na.ssl-images-amazon.com/images/I/51vETP+39aL._SX404_BO1,204,203,200_.jpg"," Android 5 Edition","The objective of this book is to teach the skills necessary to develop Android applications using Android Studio and the Android 5 Software Development Kit (SDK). "));
            allBooks.add(new Book(5,"Rich Dad Poor Dad","Robert T. Kiyosaki",336,"https://images-na.ssl-images-amazon.com/images/I/81bsw6fnUiL.jpg","Rich Dad Poor Dad: What the Rich Teach Their Kids About Money That the Poor and Middle Class Do Not!","It's been nearly 25 years since Robert Kiyosaki’s Rich Dad Poor Dad first made waves in the Personal Finance arena.\n" +
                    "It has since become the #1 Personal Finance book of all time... translated into dozens of languages and sold around the world."));
            allBooks.add(new Book(6,"Java: Programming Basics for Beginners "," LPF Publishing ",103,"https://m.media-amazon.com/images/I/41XaM6266ML.jpg","★ Java Made Easy – A Step-by-Step Guide for Beginners ★","\n" +
                    "Java is one of the most popular and widely used programming languages available. Most of the modern applications built around the world are made from the Java programming language. Its portability and ease of use has ensured that it remains in demand."));
        }

        if (null == alreadyReadBooks) {
            alreadyReadBooks = new ArrayList<>();
        }
        if (null == wantToReadBooks) {
            wantToReadBooks = new ArrayList<>();
        }
        if (null == currentlyReadingBooks) {
            currentlyReadingBooks = new ArrayList<>();
        }
        if (null == favoriteBooks) {
            favoriteBooks = new ArrayList<>();
        }
    }

    public static Utils getInstance() {
        if (null != instance) {
            return instance;
        } else {
            instance = new Utils();
            return instance;
        }
    }

    public static ArrayList<Book> getAllBooks() {
        return allBooks;
    }

    public static ArrayList<Book> getAlreadyReadBooks() {
        return alreadyReadBooks;
    }

    public static ArrayList<Book> getWantToReadBooks() {
        return wantToReadBooks;
    }

    public static ArrayList<Book> getCurrentlyReadingBooks() {
        return currentlyReadingBooks;
    }

    public static ArrayList<Book> getFavoriteBooks() {
        return favoriteBooks;
    }

    public Book getBookById(int id) {
        for (Book b : allBooks) {
            if (b.getId() == id) {
                return b;
            }
        }
        return null;
    }

    public boolean addToAlreadyRead(Book book) {
        return alreadyReadBooks.add(book);
    }

    public boolean addToWantToRead(Book book) {
        return wantToReadBooks.add(book);
    }

    public boolean addToCurrentlyReading(Book book) {
        return currentlyReadingBooks.add(book);
    }

    public boolean addToFav(Book book) {
        return favoriteBooks.add(book);
    }
}
